import sys
print('sys.argv is', sys.argv)
